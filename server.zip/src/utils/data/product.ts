export const sampleProduct = {
  name: 'Sample name',
  price: 0,
  image: '/images/sample.jpg',
  brand: 'Sample brand',
  category: 'Sample category',
  numReviews: 0,
  countInStock: 0,
  description: 'Sample description',
};
